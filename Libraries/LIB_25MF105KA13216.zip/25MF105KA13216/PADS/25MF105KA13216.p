*PADS-LIBRARY-PART-TYPES-V9*

25MF105KA13216 CAPC3216X120N I CAP 7 1 0 0 0
TIMESTAMP 2026.06.05.16.42.38
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" Rubycon
"Manufacturer_Part_Number" 25MF105KA13216
"Description" Film Capacitors 3216 25VDC 1uF 10%
"Datasheet Link" https://www.rubycon.co.jp/wp-content/uploads/catalog-pmlcap/MF.pdf
"Geometry.Height" 1.2mm
GATE 1 2 0
25MF105KA13216
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
21496321/2072983/2.50/2/3/Capacitor
