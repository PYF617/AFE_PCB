*PADS-LIBRARY-PART-TYPES-V9*

CB057D0105JBC CAPC7361X470N I CAP 7 1 0 0 0
TIMESTAMP 2026.06.19.12.23.45
"Farnell Part Number" 
"Farnell Price/Stock" 
"Manufacturer_Name" Kyocera AVX
"Manufacturer_Part_Number" CB057D0105JBC
"Description" 1 F Film Capacitor 40V 63V Polyester, Polyethylene Naphthalate (PEN), Metallized - Stacked 2824 (7260 Metric)
"Datasheet Link" https://datasheets.kyocera-avx.com/cb-pen.pdf
"Geometry.Height" 4.7mm
GATE 1 2 0
CB057D0105JBC
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
17605876/2072983/2.50/2/3/Capacitor
