*PADS-LIBRARY-PART-TYPES-V9*

TS5A3153DCUR SOP50P310X90-8N I ANA 7 1 0 0 0
TIMESTAMP 2026.06.01.14.55.10
"Mouser Part Number" 595-TS5A3153DCUR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TS5A3153DCUR?qs=BBezV1N05%2FshGMJPJGj1vg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TS5A3153DCUR
"Description" 1-Ohm SPDT Analog Switch 5-V/3.3-V Single-Channel 2:1 Multiplexer/Demultiplexer
"Datasheet Link" http://www.ti.com/lit/gpn/ts5a3153
"Geometry.Height" 0.9mm
GATE 1 8 0
TS5A3153DCUR
1 0 U COM
2 0 U \EN
3 0 U GND_1
4 0 U GND_2
8 0 U V+
7 0 U NC
6 0 U NO
5 0 U IN

*END*
*REMARK* SamacSys ECAD Model
751730/2072983/2.50/8/3/Integrated Circuit
