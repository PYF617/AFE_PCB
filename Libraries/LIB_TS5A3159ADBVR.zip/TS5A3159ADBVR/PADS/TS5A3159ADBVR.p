*PADS-LIBRARY-PART-TYPES-V9*

TS5A3159ADBVR SOT95P280X145-6N I ANA 7 1 0 0 0
TIMESTAMP 2026.06.17.14.54.50
"Farnell Part Number" 
"Farnell Price/Stock" 
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TS5A3159ADBVR
"Description" 1 Ohm SPDT Analog Switch 5-V/3.3-V Single Channel 2:1 Multiplexer/Demultiplexer
"Datasheet Link" http://www.ti.com/lit/gpn/ts5a3159a
"Geometry.Height" 1.45mm
GATE 1 6 0
TS5A3159ADBVR
1 0 U NO
2 0 U GND
3 0 U NC
6 0 U IN
5 0 U V+
4 0 U COM

*END*
*REMARK* SamacSys ECAD Model
276253/2072983/2.50/6/3/Integrated Circuit
