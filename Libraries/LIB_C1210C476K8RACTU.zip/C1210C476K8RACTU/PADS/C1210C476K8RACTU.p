*PADS-LIBRARY-PART-TYPES-V9*

C1210C476K8RACTU C1210 I CAP 6 1 0 0 0
TIMESTAMP 2026.06.19.11.58.48
"Farnell Part Number" 
"Farnell Price/Stock" 
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" C1210C476K8RACTU
"Description" SMD, MLCC, Temperature Stable, Class II
"Datasheet Link" https://www.yageogroup.com/content/datasheet/asset/file/KEM_C1002_X7R_SMD
GATE 1 2 0
C1210C476K8RACTU
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1010041/2072983/2.50/2/2/Capacitor
