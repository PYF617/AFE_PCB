*PADS-LIBRARY-PART-TYPES-V9*

FOD050L SOIC127P594X363-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.06.01.11.47.37
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" FOD050L
"Mouser Part Number" 512-FOD050L
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi-Fairchild/FOD050L?qs=ReZUMDdiXnRPjBKyX9bkKw%3D%3D
"Arrow Part Number" FOD050L
"Arrow Price/Stock" https://www.arrow.com/en/products/fod050l/on-semiconductor?region=nac
"Description" DIN-EN/IEC60747-5-5, 565 V Peak Working Insulation Voltage; Safety and Regulatory Approvals:; UL1577, 2,500 VACRMS for 1 Minute; Available in Single-channel 8-pin SOIC (FOD050L) or Dual-channel 8-pin SOIC (FOD053L); Guaranteed performance over temperature:m0C to 70C; Superior CMR  CMH = 50 kV/us (typical) and CML = 35 kV/us (typical); Low Power Consumption; High Speed
"Datasheet Link" https://www.onsemi.com/pub/Collateral/FOD053L-D.PDF
"Geometry.Height" 3.63mm
GATE 1 8 0
FOD050L
1 0 U NC
2 0 U VF+
3 0 U VF-
4 0 U N/C
8 0 U VCC
7 0 U VB
6 0 U VO
5 0 U GND

*END*
*REMARK* SamacSys ECAD Model
438988/2072983/2.50/8/2/Integrated Circuit
