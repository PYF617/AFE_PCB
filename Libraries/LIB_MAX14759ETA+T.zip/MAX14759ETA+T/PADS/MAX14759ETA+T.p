*PADS-LIBRARY-PART-TYPES-V9*

MAX14759ETA+T SON65P300X300X80-9N I ANA 9 1 0 0 0
TIMESTAMP 2026.06.02.12.34.28
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" MAX14759ETA+T
"Mouser Part Number" 700-MAX14759ETA+T
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices-Maxim-Integrated/MAX14759ETA%2bT?qs=2cAdsCoAWRFgTjPJwgxqqQ%3D%3D
"Arrow Part Number" MAX14759ETA+T
"Arrow Price/Stock" https://www.arrow.com/en/products/max14759etat/analog-devices?utm_currency=USD&region=nac
"Description" Above- and Below-the-Rails Low On-Resistance Analog Switches
"Datasheet Link" https://datasheets.maximintegrated.com/en/ds/MAX14759-MAX14763.pdf
"Geometry.Height" 0.8mm
GATE 1 9 0
MAX14759ETA+T
1 0 U VCC
2 0 U GND
3 0 U VN
4 0 U B
9 0 U EP
8 0 U EN
7 0 U N.C.
6 0 U VP
5 0 U A

*END*
*REMARK* SamacSys ECAD Model
240352/2072983/2.50/9/3/Integrated Circuit
